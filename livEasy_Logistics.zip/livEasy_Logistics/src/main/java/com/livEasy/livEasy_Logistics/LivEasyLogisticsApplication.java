package com.livEasy.livEasy_Logistics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class LivEasyLogisticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivEasyLogisticsApplication.class, args);
	}
}
