package com.livEasy.livEasy_Logistics.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.livEasy.livEasy_Logistics.Model.Load;
import com.livEasy.livEasy_Logistics.Repository.LoadRepository;
import com.livEasy.livEasy_Logistics.Service.ServiceLayer;

@RestController
public class LoadController {
    @Autowired
    private ServiceLayer serviceLayer;
    @Autowired
    private LoadRepository loadRepository;

    @GetMapping("/load/{id}")
    public Load getLoadById(@PathVariable Long id){
        return serviceLayer.getLoadById(id);
    }

    @PostMapping("/load")
    public ResponseEntity<String> addLoad(@RequestBody Load load) {
        serviceLayer.addLoad(load);
        return ResponseEntity.ok("Load details added successfully");
    }

    @GetMapping("/load")
    public List<Load> getAll(){
        return loadRepository.findAll();
    }

    @DeleteMapping("/load/{loadid}")
    public void deleteById(@PathVariable Long loadid){
        serviceLayer.deleteLoad(loadid);
        System.out.println("Deleted");
    }

    @PutMapping("/{loadId}")
    public ResponseEntity<Load> updateLoad(@PathVariable Long loadId, @RequestBody Load updatedLoad) {
        Load load = serviceLayer.updateLoad(loadId, updatedLoad);
        return ResponseEntity.ok(load);
    }

    @GetMapping("/{loadId}")
    public ResponseEntity<List<Load>> getLoadsByShipperId(@RequestParam Long shipperId) {
        List<Load> loads = serviceLayer.getLoadsByShipperId(shipperId);
        return ResponseEntity.ok(loads);
    }
}
