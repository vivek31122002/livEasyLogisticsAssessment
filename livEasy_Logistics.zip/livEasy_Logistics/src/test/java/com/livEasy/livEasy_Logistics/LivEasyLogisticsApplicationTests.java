package com.livEasy.livEasy_Logistics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivEasyLogisticsApplicationTests {

	@Test
	void contextLoads() {
	}

}
